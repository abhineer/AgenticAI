# LangChain Agent Project

Supports factual, analytical, comparison, and definition queries.